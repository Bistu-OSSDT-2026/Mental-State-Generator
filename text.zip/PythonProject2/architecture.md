# Mental-State-Generator 系统架构设计文档
## 文档基础信息
- 项目名称：情绪配图文案生成工具 Mental-State-Generator
- 开发小组：巨神战机队
- 编写日期：2026.07.02
- 技术栈：原生HTML + CSS + JavaScript + Canvas
- 运行模式：纯前端离线单页应用，无后端依赖
- 代码仓库：Gitee项目仓库地址

## 一、分层架构设计（四层单向解耦）
整体采用分层架构，上层仅调用下层对外暴露接口，下层不反向依赖上层，模块独立可单独迭代修改。
1. **数据层（底层）**
    对应文件：`js/textData.js`
    核心职责：仅存储静态文案分类数据，无业务逻辑；新增、修改文案仅操作此文件，不影响渲染与交互逻辑。
2. **业务核心调度层（中间枢纽）**
    对应文件：`js/textCore.js`
    核心职责：统一处理分类切换、随机文本抽取、文字对齐参数计算；封装通用方法，隔离数据层与画布渲染层。
3. **Canvas渲染层**
    对应文件：
    - `js/canvas/canvasBase.js`：画布初始化、清空、尺寸管理基础能力
    - `js/canvas/canvasText.js`：文字绘制、对齐位置渲染
    - `js/canvas/canvasSticker.js`：背景图、装饰贴纸绘制
    核心职责：仅接收参数执行绘图操作，不参与文案筛选、分类逻辑。
4. **视图交互层（顶层入口）**
    对应文件：项目根目录HTML页面
    核心职责：绑定页面按钮、分类标签的点击交互事件，调用业务核心层对外接口，不存放复杂计算逻辑。

### 模块依赖流程图
```mermaid
graph LR
    A[HTML视图交互层] --> B[textCore.js 业务核心层]
    B --> C[textData.js 数据素材层]
    B --> D[Canvas渲染模块]
    D --> D1[canvasBase.js 画布基础]
    D --> D2[canvasText.js 文字绘制]
    D --> D3[canvasSticker.js 贴纸/背景绘制]
